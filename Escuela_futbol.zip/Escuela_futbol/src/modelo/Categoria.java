
package modelo;

import contrrolador.Controlador;
import java.beans.Statement;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Jugadores;
public class Categoria {

    public static Statement createStatement() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static int buscar(String aeliminar) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    private Jugadores [] jugadores;
    private int Edad;
    
    


    public Categoria(int tam) {
        this.jugadores = new Jugadores[tam];
        this.Edad = Edad;
    }
    
    public Jugadores getJugadores(int pos) {
        return jugadores[pos];
    }

    public void setJugadores(Jugadores jugadores, int pos) {
        this.jugadores[pos] = jugadores;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }
    
       public String agregarJugadores(){
        String msj = "" ;
        msj += " Edad \t Identificacion \t Nombre \t Posicion  \t Categoria  \n";
        for(int a =0;a < get_lengt();a++){
            if (getJugadores(a)!=null){
            msj += getJugadores(a).getEdad()+"\t";
            msj += getJugadores(a).getId()+"\t";
            msj += getJugadores(a).getNom()+"\t";
            msj += getJugadores(a).getPos()+"\t";
            msj += getJugadores(a).getPro()+"\t";
            msj += getJugadores(a).getCate()+"\n";
        }
        }
        return msj;
    }
       
        
      public int get_lengt(){
        return this.jugadores.length;
    }
      
       

      public String leerAchio(String ac) {

        String msj = "";
        File Archivo = new File(ac);
        try {
            BufferedReader entrada = new BufferedReader(new FileReader(Archivo));
            String lectura = entrada.readLine();
//            System.out.println(lectura);
            while (lectura != null) {
                msj += lectura + "\n";
                lectura = entrada.readLine();

                System.out.println(msj);
                // lectura = entrada.readLine();
            }
            entrada.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return msj;
    }


      
    public String leerlinea(String jugadores) {
         String msj = "";
         String Jugadores = jugadores;
    try {
       FileReader fr = new FileReader("jugadores.txt");
        BufferedReader br = new BufferedReader(fr);

        String linea;
        while((linea = br.readLine()) != null)
             msj += linea+ "\n";
           System.out.println(msj);
        br.close();
        fr.close();
    } catch(Exception e) {
       // System.out.println("Excepcion leyendo fichero "+ Jugadores + ": " + e);
         e.printStackTrace();
    }
        return msj;
      
    }
    
    public void muestraContenido(String archivo) throws FileNotFoundException, IOException { 
        String otra="";
	String cadena;
	FileReader f = new FileReader(archivo); 
	BufferedReader b = new BufferedReader(f); 
        String msj = "jugadores"+"\n";
        msj +=" Prod\n";
	while((cadena = b.readLine())!=null) { 
            otra += cadena+"\n";
		
	} 
        //vi.txtarchivo.setText(otra); 
	b.close(); 
        
}
    /* public  void borrarLinea() throws IOException {
      
        File inputFile = new File("jugadores.txt");
        File tempFile = new File("jugadores_1.txt");
        BufferedReader leer = new BufferedReader(new FileReader(inputFile));
        BufferedWriter escribir = new BufferedWriter(new FileWriter(tempFile));
        int lineaeliminar;
        lineaeliminar = Integer.parseInt(vi.txtnumlin.getText());
        String listaactual;
        int contar = 0; 
        while ((listaactual = leer.readLine()) != null) {
            contar++;
            if (contar == lineaeliminar) {
                continue;
            }
            escribir.write(listaactual + System.getProperty("line.separator"));
        }
        escribir.close();
        leer.close();
        inputFile.delete();
        tempFile.renameTo(inputFile);
    }*/
  
    
}
            
            

    
 

      
      
      

       


 



package modelo;


public class Reportes {
    
     private Reportes [] delanteros;
    private String nom;
    private String pos;

    public Reportes(Reportes[] delanteros, String nom, String pos) {
        this.delanteros = delanteros;
        this.nom = nom;
        this.pos = pos;
    }

 

    public Reportes getDelanteros(int pos) {
        return delanteros [pos];
    }

    public void setDelanteros(Reportes delanteros,int pos) {
        this.delanteros[pos] = delanteros;
    }
    
          public String agregarDelanteros(){
        String msj = "" ;
        msj += " Nombre \t Posicion  \n";
        for(int a =0;a < get_lengt();a++){
            if (getDelanteros(a)!=null){
            msj += getDelanteros(a).getNom()+"\t";
            msj += getDelanteros(a).getPos()+"\n";
        }
        }
        return msj;
    }
       
        
      public int get_lengt(){
        return this.delanteros.length;
    }

    private String getNom() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String getPos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}

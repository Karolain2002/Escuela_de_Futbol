
package modelo;

import java.awt.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Jugadores {


    private String nom;
    private String id;
    private int Edad = 0;
    private String Pos;
    private String Pro;
    private String cate;
    private String ed;
 
    
    private File file;
    private FileWriter write_file;
    private String juadores_file;
    int length;
    private String File;

    
    public Jugadores(){
        this.Edad = 0;
        this.Pos = "";
        this.id = "";
        this.nom = "";
        this.Pro = "";
        this.cate="";
        this.ed ="";
        this.file = null;
        this.write_file = null;
        this.juadores_file = "";
        
    }

    
    

    public String getEd() {
        return ed;
    }

    public void setEd(String ed) {
        this.ed = ed;
    }
    
    public String getJuadores_file() {
        return juadores_file;
    }

    public void setJuadores_file(String juadores_file) {
        this.juadores_file = juadores_file;
    }
    
    
    public String getCate() {
        return cate;
    }

    public void setCate(String cate) {
        this.cate = cate;
    }
    

    public String getPro() {
        return Pro;
    }

    public void setPro(String Pro) {
        this.Pro = Pro;
    }
    
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    public String getPos() {
        return Pos;
    }

    public void setPos(String Pos) {
        this.Pos = Pos;
    }
    
     public String create_file(String juadores_file){
        setJuadores_file(juadores_file);
        String message = "";
        this.file = new File(getJuadores_file());
        if(!this.file.exists()){
            try {
                this.file.createNewFile();
                message = "Archivo creado";
            } catch (IOException ex) {
               ex.printStackTrace();
            }
        }else{
            message="El archivo ya existe";
        }
        return message;
    }
    
    public void append_to_file(String lineToAppend) throws IOException{
         byte[] Jugadores = lineToAppend.getBytes();
        Files.write(Paths.get(getJuadores_file()), Jugadores, StandardOpenOption.APPEND);
    }

    public void FielDelet() {
       File file = new File("jugadores.txt");
		if(file.exists()){
			if(file.delete()){
				System.out.println("Se eliminó el fichero");
			}
		}else{
			System.out.println("El fichero no existe.");
		}
       String message ="";
    }
    
    public void grabar(String cadena){
            try{
              FileWriter jugadores =new FileWriter ("jugadores.txt",true);
              try(BufferedWriter almacen = new BufferedWriter(jugadores)){
                almacen.write(cadena);
                almacen.close();
              }
              jugadores.close();
          }catch(Exception ex){
              
        }
            
    }
       public String eliminar(){
    
        File tempFile = new File("jugadores.txt");
        File tempFile2 = new File("jugadores2.txt");
        
        BufferedWriter write;
        BufferedReader reader;
        var lista = new ArrayList<String>();
        
        try {
            write = new BufferedWriter(new FileWriter(tempFile2));
            reader = new BufferedReader(new FileReader(tempFile));
            String cadena;
            while((cadena = reader.readLine())!=null) { 
                lista.add(cadena);
            } 
            
            String lineToRemove = "2";
            for (String string : lista) {
                String data[] = string.split(",");
                if(!data[2].equalsIgnoreCase(lineToRemove))
                    write.write(data[0] + "," + data[1] + "\n");
            }
            write.close();
            reader.close();
        } catch (IOException e) {
            System.err.println("No se encuentra el archivo");
            e.printStackTrace();
        }
        return null;
        
    }
       
       
       /*  DefaultTableModel modelo=(DefaultTableModel) tblDatos.getModel();   
         Object [] fila=new Object[6]; 

            fila[0]=getNom.getText(); 
            fila[1]=vi.txtid.getText(); 
            fila[2]=vi.txtEdad.getText(); 
            fila[3]=vi.txtPro.getText(); 
            fila[4]=vi.txtcantidad.getText(); 

         modelo.addRow(fila); 

        tblDatos.setModel(modelo); */
        
    }
   






package contrrolador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.Statement;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import static java.lang.System.in;
import static java.lang.reflect.Array.get;
import static java.nio.file.Paths.get;
import java.text.DecimalFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import static javax.swing.UIManager.get;
import javax.swing.table.DefaultTableModel;
import modelo.Categoria;
import modelo.Jugadores;
import modelo.Reportes;
import vista.Vista;


public class Controlador implements ActionListener{
    
    private Categoria cat;
    private Vista vi;
    private int Pos ;
    private Reportes rep;
    private Jugadores jug;
    
     int def=0,ed=0,id,promedio =0;
     String ide = "",info="",eda,elim="";
    boolean eli = true;
     float name;
     
     DecimalFormat f1 = new DecimalFormat("############.#%");

    public Controlador(Vista vi, Categoria cat) {
         this.cat = cat;
        this.vi = vi;
        this.Pos = Pos;
        this.jug =jug;
        
        this.vi.btnAgregar.addActionListener(this);
        this.vi.btnMostrar1.addActionListener(this);
        this.vi.btnMostrar2.addActionListener(this);
        this.vi.btnMostrar3.addActionListener(this);
        this.vi.btnEliminar.addActionListener(this);
        this.vi.btnMostrar4.addActionListener(this);
        this.vi.btnSalir.addActionListener(this);
        this.vi.btnLimpiar.addActionListener(this);
    }
   
        
    
     public void iniciar(){
        vi.setTitle("Escuela de Futbol....");
        vi.setLocationRelativeTo(null);
    }
     
      public void Limpiar(){
         vi.txtEdad.setText("");
         vi.txtNom.setText("");
         vi.txtid.setText("");
         vi.txtPro.setText("");
         vi.txtEdad.requestFocus();
     }
     
    
     public void Agregar(){
       
        
        Jugadores temp = new Jugadores();
        temp.setNom(vi.txtNom.getText());
        temp.setId(vi.txtid.getText());
        temp.setEdad(Integer.parseInt(vi.txtEdad.getText()));
        temp.setPro(vi.txtPro.getText());
        temp.setPos(vi.cmbPos.getSelectedItem().toString());
        
      
        
        if(temp.getPos()=="Delantero"){
            def=def+1;
             info += temp.getNom()+ " "+ temp.getId()+" "+temp.getEdad()+" "+temp.getPro()+" " +temp.getPos()+" "+"\n";
        }
         
       if(temp.getPos()=="Defensa"&&(temp.getEdad()>=9)&&(temp.getEdad()<=12)){
          ed = ed+1;
           name = (temp.getEdad())/ed;
    }
       
        if((temp.getEdad()>=9)&&(temp.getEdad()<=12)){
             ide +=  temp.getNom()+" "+ temp.getPos()+"\n";
        }
            

        if((temp.getEdad()>=9)&&(temp.getEdad()<=12)){
            temp.setCate("Infantil");
              }else if ((temp.getEdad()>=13)&&(temp.getEdad()<=15)){
                 temp.setCate("Junior");   
               }else 
                 temp.setCate("sin categoria");
 
          if(cat.get_lengt()> this.Pos ){
             JOptionPane.showMessageDialog(null, "se ingresaron los datos correctamente");
             cat.setJugadores(temp,Pos);
             Pos ++;
        }else{
            cat.setJugadores(temp,Pos);
                this.Pos ++; 
                JOptionPane.showMessageDialog(null, "no se puede ingresar mas datos ");
            }  
  
          Jugadores conexion = new Jugadores();
          conexion.grabar(vi.txtEdad.getText() + "\t" + vi.txtid.getText().toString() + "\t"+ vi.txtNom.getText().toString()+"\t"+ vi.cmbPos.getSelectedItem().toString()+"\n"+vi.txtPro.getText().toString());
        
     }
     
     public void Mostrar_1(){
        vi.txaCanInf.setText(cat.agregarJugadores());

     }
     
     public void Mostrar_2(){
      vi.txaDelantero1.setText(info);
      vi.txtPro.setText(f1.format((name  /100)));
      vi.txtcantidad.setText(Integer.toString(def));
     }
     
     public void Mostrar_3(){
         vi.txaJugadores.setText(ide);
     }
     
     public void Mostrar_4(){
         vi.txaJugadoresEli.setText(cat.leerlinea(cat.agregarJugadores()));
     }
     
     public void Eliminar()throws IOException{
      
        File inputFile = new File("jugadores.txt");
        File tempFile = new File("jugadores_1.txt");
        BufferedReader leer = new BufferedReader(new FileReader(inputFile));
        BufferedWriter escribir = new BufferedWriter(new FileWriter(tempFile));
        int lineaeliminar;
        lineaeliminar = Integer.parseInt(vi.txtEliminar.getText());
        String listaactual;
        int contar = 0; 
        while ((listaactual = leer.readLine()) != null) {
            contar++;
            if (contar == lineaeliminar) {
                continue;
            }
            escribir.write(listaactual + System.getProperty("line.separator"));
        }
        escribir.close();
        leer.close();
        inputFile.delete();
        tempFile.renameTo(inputFile);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==vi.btnAgregar){
            Agregar();
        }if (e.getSource()==vi.btnMostrar1){
            Mostrar_1();
        }if (e.getSource()==vi.btnMostrar2){
            Mostrar_2();
        }if (e.getSource()==vi.btnMostrar3){
            Mostrar_3();
        }if (e.getSource()==vi.btnMostrar4){
            Mostrar_4();
        }if (e.getSource()==vi.btnEliminar){
            try {
                Eliminar();
            } catch (IOException ex) {
                Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
            }
        }if (e.getSource()==vi.btnLimpiar){
            Limpiar();
        }if (e.getSource()==vi.btnSalir){
            System.exit(0);
        } 
        
     }
}    
    
     





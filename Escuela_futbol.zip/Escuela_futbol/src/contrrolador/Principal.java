
package contrrolador;

import contrrolador.Controlador;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.lang.String;
import modelo.Categoria;
import modelo.Jugadores;
import vista.Vista;


public class Principal {
    
     public static void main(String[] args)throws IOException{
        Vista   vi = new Vista();
        Categoria cat =new Categoria(10);
        Controlador co = new Controlador (vi,cat);
        co.iniciar();
        vi.setVisible(true);
        
        Jugadores file_1 = new Jugadores();
        System.out.println(file_1.create_file("Jugadores.txt"));
        file_1.append_to_file(cat.agregarJugadores());
        
        
      
}

    
}
